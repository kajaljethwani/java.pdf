class A
{
	protected void dispA()
	{
		System.out.println("class A");
	}
	
}
class B extends A
{
	void dispB()
	{
		dispA();
		System.out.println("class B");
	}
}
class SingInh2
{
	public static void main (String args[])
	{
		B b1;
		
		b1 = new B();
		b1.dispA();
		b1.dispB();
	}
}