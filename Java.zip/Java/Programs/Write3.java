import java.io.*;
import java.util.*;
class Write3
{
	public static void main(String args[]) throws Exception
	{
		Scanner sc = new Scanner(System.in);
		String s;
		FileOutputStream fos = new FileOutputStream("d://brijesh//java//test3.txt");
		while(true)
		{
			System.out.println("Enter string:");
			s = sc.nextLine();
			if(s.length()==0)
				break;
			byte b[] = s.getBytes();
			fos.write(b);
		}
		fos.close();
	}
}