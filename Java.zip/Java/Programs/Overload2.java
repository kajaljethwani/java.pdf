class B
{
	int a, b;
	int sum(int a, int b)
	{
		System.out.println("Int Sum");
		return(a+b);
	}
	float sum(float a, float b)
	{
		System.out.println("Float Sum");
		return(a+b);
	}
}
class Overload2
{
	public static void main(String args[])
	{
		float x=100, y=200;
		B b1 = new B();
		System.out.println("Sum of two int nos="+b1.sum(10,20));
		System.out.println("Sum of three float nos="+b1.sum(x,y));
	}
}