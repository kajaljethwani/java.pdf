class Varargs1
{
	static int sum(int... n)
	{
		int sum  = 0;
		System.out.println("");
		for(int n1 : n)
		{
			System.out.print(n1 + " ");
			sum += n1;
		}
		return(sum);
	}
	public static void main(String args[])
	{
		System.out.println("Two args sum ="+sum(10,20));
		System.out.println("Three args sum ="+sum(10,20,30));
		System.out.println("Four args sum ="+sum(10,20,30,40));
	}
}