interface A
{
	void dispA();
}

interface B
{
	void dispB();
}

class C implements A, B  // Multiple Inheritance
{
	public void dispA()
	{
		System.out.println("Interface A");
	}
	public void dispB()
	{
		System.out.println("Interface B");
	}
	void dispC()
	{
		System.out.println("CLass C");
	}
}

class Interface2
{
	public static void main(String args[])
	{
		C c1 = new C();
		c1.dispA();
		c1.dispB();
		c1.dispC();
	}
}