class A		// Grand Parent
{
	void dispA()
	{
		System.out.println("class A");
	}
	
}
class B extends A	//Parent
{
	void dispB()
	{
		System.out.println("class B");
	}
}

class C extends B	// Child
{
	void dispC()
	{
		System.out.println("class C");
	}
}

class MultiLevel1
{
	public static void main (String args[])
	{
		C c1 = new C();
		c1.dispA();
		c1.dispB();
		c1.dispC();
	}
}