
class Exception2
{
	public static void main(String args[])
	{
		int a, b, c;
		try
		{
			a = Integer.parseInt(args[0]);
			b = Integer.parseInt(args[1]);
			c = a / b;
			System.out.println("c ="+c);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Array Index Error");
		}
		catch(ArithmeticException e)
		{
			System.out.println("Arithmetic Error");
		}
		catch(NumberFormatException e)
		{
			System.out.println("Type Mismatch Error");
		}
		System.out.println("End");
	}
}