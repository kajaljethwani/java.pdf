class String1
{
	public static void main(String args[])
	{
		String s1 = "String Using Litral"; // string litral
		String s2 = new String("String Using new");
		char c1[] = {'a','b','c','d','e'};
		String s3 = new String(c1);
		System.out.println("s1 ="+s1);
		System.out.println("s2 ="+s2);
		System.out.println("s3 ="+s3);
		System.out.println("charAt(3) =" + s1.charAt(3));
		System.out.println("substring(7,12) =" + s1.substring(7,12));
		System.out.println("contains(U) =" + s1.contains("U"));
		System.out.println("join( ,a,b,c,d) =" + s1.join(" ","a","b","c","d"));
		System.out.println("s1 =" + s1);
		System.out.println("s2 =" + s2);
		System.out.println("s3 =" + s3);
		String s4 = "Abcde";
		if(s3.equals(s4))
			System.out.println("Same");
		else
			System.out.println("Different");
		if(s3.equalsIgnoreCase(s4))
			System.out.println("Same");
		else
			System.out.println("Different");
		Object obj1 = s1.getClass();
		System.out.println(obj1.toString());
	}
}