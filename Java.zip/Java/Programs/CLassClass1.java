public class CLassClass1 
{  
    public static void main(String[] args) throws ClassNotFoundException, IllegalAccessException
	{  
        // returns the Class object for the class with the given name  
        Class class1 = Class.forName("java.lang.String");  
        Class class2 = int.class;  
        System.out.print("Class represented by class1: ");  
        // applying toString method on class1  
        System.out.println(class1.toString());  
        System.out.print("Class represented by class2: ");  
        // applying toString() method on class2  
        System.out.println(class2.toString());  
        String s = "JavaTpoint";  
        int i = 10;  
		Integer j = new Integer(i);
        // checking for Class instance  
        boolean b1 = class1.isInstance(s);  
        boolean b2 = class2.isInstance(j);  
        System.out.println("is p instance of String : " + b1);  
        System.out.println("is j instance of Integer : " + b2);  
		System.out.println("is j = : " + j);  
    }  
}  

