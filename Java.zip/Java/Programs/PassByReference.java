class X2
{
	int a, b;
	X2(int a, int b)
	{
		this.a = a;
		this.b = b;
	}
	X2 swap(X2 x2)
	{
		int c = x2.a;
		x2.a = x2.b;
		x2.b = c;
		System.out.println("Inside Swap:");
		System.out.println("a="+x2.a+"\t b="+x2.b);
		return x2;
	}
}

class PassByReference
{
	public static void main(String args[])
	{
		X2 x2 = new X2(10, 20);
		
		System.out.println("Before Swap:");
		System.out.println("a="+x2.a+"\t b="+x2.b);
		x2 = x2.swap(x2);
		System.out.println("After Swap:");
		System.out.println("a="+x2.a+"\t b="+x2.b);
	}
}