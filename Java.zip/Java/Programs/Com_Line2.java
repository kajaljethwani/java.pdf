class Com_Line2
{
	public static void main(String args[])
	{
		int i, sum = 0, l, n;
		float avg;
		l = args.length;
		
		for(i=0 ; i<l ; i++)
		{
			System.out.println(args[i]);
			n = Integer.parseInt(args[i]);
			sum += n;
		}
		avg = sum / l;
		System.out.println("Sum ="+sum);
		System.out.println("Avg ="+avg);
	}
}