import java.util.*;
class For1
{
	public static void main(String args[])
	{
		int n, i, j;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter n:");
		n = sc.nextInt();
		for(i=1 ; i<=n ; i++)
		{
			System.out.print(i + " ");
		}
		System.out.println("");
		for(i=1 ; i<=n ; ++i)
		{
			System.out.print(i + " ");
		}
		System.out.println("");
		for(i=1 ; i<=n ; i++);
		{
			System.out.print(i + " ");
		}
		System.out.println("");
		i=1;
		for( ; ; )
		{
			System.out.print(i++ + " ");
			if(i>10)
				break;
		}
		System.out.println("");
		for(i=1, j=n ; i<=n ; i++, j--)
		{
			System.out.print(i + " " + j + " ");
		}
		System.out.println("");
	}
}