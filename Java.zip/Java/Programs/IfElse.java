import java.util.*;

class IfElse
{
	public static void main(String args[])
	{
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		n = sc.nextInt();
		if(n%2==0)
		{
			System.out.println("No. Is Even");
		}
		else
		{
			System.out.println("No. Is Odd");
		}
	}
}