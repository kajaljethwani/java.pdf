import java.io.*;

class Write1
{
	public static void main(String args[]) throws Exception
	{
		
		FileOutputStream fos = new FileOutputStream("d://brijesh//java//test1.txt");
		fos.write(65);
		fos.close();
	}
}