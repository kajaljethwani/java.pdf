import java.io.*;  
import java .util.*;

public class ReaderExample 
{  
	public static void main(String[] args) 
	{  
		try 
		{  
			Scanner sc = new Scanner(System.in);
			String s;
			System.out.println("Enter file name");
			s = sc.nextLine();
			Reader reader = new FileReader(s);  
			int data ;  
			while ((data =reader.read()) != -1) 
			{  
				System.out.print((char)data);  
				//data = reader.read();  
			}  
			reader.close();  
		} 
		catch (Exception ex) 
		{  
			System.out.println(ex.getMessage());  
		}  
	}  
}  
