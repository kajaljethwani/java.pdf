import java.util.*;

class ElseIfLadder
{
	public static void main(String args[])
	{
		float avg;;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter average marks:");
		avg = sc.nextFloat();
		if(avg>=70)
		{
			System.out.println("Distinction");
		}
		else if(avg>=60)
		{
			System.out.println("First");
		}
		else if(avg>=50)
		{
			System.out.println("Second");
		}
		else if(avg>=40)
		{
			System.out.println("Pass");
		}
		else
		{
			System.out.println("Try Again");
		}
	}
	
} 