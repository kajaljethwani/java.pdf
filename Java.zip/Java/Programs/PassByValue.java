class X1
{
	void swap(int a, int b)
	{
		int c = a;
		a = b;
		b = c;
		System.out.println("Inside Swap:");
		System.out.println("a="+a+"\t b="+b);
	}
}

class PassByValue
{
	public static void main(String args[])
	{
		X1 x1 = new X1();
		int a = 10, b = 20;
		System.out.println("Before Swap:");
		System.out.println("a="+a+"\t b="+b);
		x1.swap(a, b);
		System.out.println("After Swap:");
		System.out.println("a="+a+"\t b="+b);
	}
}