//	Print all Divisiors Of the no.

import java.util.*;
class Divisior
{
	public static void main(String args[])
	{
		int n, i;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter n:");
		n = sc.nextInt();
		for(i=1 ; i<=n ; i++)
		{
			if(n%i == 0)	
				System.out.println(i);
		}
		/*if(n == i)
			System.out.println(n + " Is Prime");
			else
		System.out.println(n + " Is Not Prime");*/
	}
}
	