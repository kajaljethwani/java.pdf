import java.io.*;

public class OutputStreamWriterExample 
{  
    public static void main(String[] args) {  
  
        try 
		{  
            OutputStream outputStream = new FileOutputStream("output.txt");  
            Writer outputStreamWriter = new OutputStreamWriter(outputStream);  
  
            outputStreamWriter.write("Hello World");  
  
            outputStreamWriter.close();  
			outputStream.close();
        } 
		catch (Exception e) 
		{  
            e.getMessage();  
        }  
    }  
}  
