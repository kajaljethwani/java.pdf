class A
{
	void disp()
	{
		System.out.println("Class Demo");
	}
}

class Class1
{
	public static void main(String args[])
	{
		A a1;
		a1 = new A();
		a1.disp();
	}
}