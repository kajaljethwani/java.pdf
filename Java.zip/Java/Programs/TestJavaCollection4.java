import java.util.*;  
public class TestJavaCollection4
{  
	public static void main(String args[])
	{  
		Stack<String> stack = new Stack<String>();  
		stack.push("Ayush");  
		stack.push("Garvit");  
		stack.push("Amit");  
		stack.push("Ashish");  
		stack.push("Garima");  
		Iterator<String> itr=stack.iterator();  
		
		System.out.println("Pop(Deleted)="+stack.pop());  
		Iterator<String> itr1=stack.iterator();  
		while(itr1.hasNext())
		{  
			System.out.println(itr1.next());  
		}  
	}  
}  
