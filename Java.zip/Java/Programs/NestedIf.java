import java.util.*;

class NestedIf
{
	public static void main(String args[])
	{
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		n = sc.nextInt();
		if(n!=0)
		{
			if(n>0)
			{
				System.out.println("No. Is +VE");
			}
			else
			{
				System.out.println("No. Is -VE");
			}
		}
		else
		{
			System.out.println("No. Is Zero");
		}
	}
}