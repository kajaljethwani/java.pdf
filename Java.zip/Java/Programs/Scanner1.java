// WAP that accept different types of value
import java.util.*;

class Scanner1
{
	public static void main(String args[])
	{
		int a;
		float b;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter an int");
		a = sc.nextInt();
		System.out.println("Enter a float:");
		b = sc.nextFloat();
		System.out.println("a ="+a);
		System.out.println("b ="+b);
	}
}
			
				