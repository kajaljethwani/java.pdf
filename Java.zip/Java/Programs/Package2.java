import p1.Package1;

class Package2
{
	public static void main(String args[])
	{
		Package1 p2 = new Package1();
		p2.disp();
	}
}