class A		// Grand Parent
{
	void dispA()
	{
		System.out.println("class A");
	}
	
}
class B extends A	//Parent
{
	void dispB()
	{
		System.out.println("class B");
	}
}

class C extends B	// Child1
{
	void dispC()
	{
		System.out.println("class C");
	}
}

class D extends B 	// Child2
{
	void dispD()
	{
		System.out.println("class D");
	}
}

class Hybrid1
{
	public static void main (String args[])
	{
		C c1 = new C();
		c1.dispA();
		c1.dispB();
		c1.dispC();
		
		D d1 = new D();
		d1.dispA();
		d1.dispB();
		//d1.dispC();
		d1.dispD();
	}
}