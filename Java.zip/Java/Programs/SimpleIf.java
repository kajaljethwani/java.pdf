import java.util.*;

class SimpleIf
{
	public static void main(String args[])
	{
		int age;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter age");
		age = sc.nextInt();
		if(age>=18)
		{
			System.out.println("You are elligible for voting");
		}
		System.out.println("End");
	}
}