import java.io.*;

class Read1
{
	public static void main(String args[]) 
	{
		try
		{
			int b;
			FileInputStream fis = new FileInputStream("d://brijesh//java//test2.txt");
			b = fis.read();
			System.out.println((char)b);
			fis.close();
		}catch(Exception e)
		{
			System.out.println("Error");
		}
	}
}