import java.io.*;

class Write2
{
	public static void main(String args[]) 
	{
		try
		{
			FileOutputStream fos = new FileOutputStream("d://brijesh//java//test2.txt");
			fos.write(66);
			fos.close();
		}catch(Exception e)
		{
			System.out.println("Error");
		}
	}
}