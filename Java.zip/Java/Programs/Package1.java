package p1;

public class Package1
{
	public void disp()
	{
		System.out.println("Package1");
	}
}
