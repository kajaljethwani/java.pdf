class C
{
	C()
	{
		System.out.println("Constructor");
	}
}

class Cons1
{
	public static void main(String args[])
	{
		C c1 = new C();
	}
}
		