import java.io.*;

class Read2
{
	public static void main(String args[]) 
	{
		try
		{
			int b;
			FileInputStream fis = new FileInputStream("d://brijesh//java//test3.txt");
			while((b = fis.read())!=-1)
			{
				System.out.print((char)b);
			}
			fis.close();
		}catch(Exception e)
		{
			System.out.println("Error");
		}
	}
}